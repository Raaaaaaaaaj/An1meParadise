// import mysql from "mysql2/promise";
// import dotenv from "dotenv";

// dotenv.config();

// export const db = await mysql.createConnection({
//   host: process.env.DB_HOST,
//   user: process.env.DB_USER,
//   password: process.env.DB_PASSWORD,
//   database: process.env.DB_NAME,
// });

// try {
//   console.log("✅ MySQL Connected Successfully");
// } catch (err) {
//   console.error("❌ DB Connection Failed:", err.message);
// }

import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

export const connectDB = async () => {
  try {
    const db = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
    });

    console.log("✅ MySQL Connected Successfully");
    return db;
  } catch (err) {
    console.error("❌ DB Connection Failed:", err.message);
    return null; // important
  }
};